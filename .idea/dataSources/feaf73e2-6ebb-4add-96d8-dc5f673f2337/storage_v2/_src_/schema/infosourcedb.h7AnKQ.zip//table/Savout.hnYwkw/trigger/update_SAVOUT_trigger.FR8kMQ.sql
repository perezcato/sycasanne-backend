create definer = rootinfosourcedb@`%.%.%.%` trigger update_SAVOUT_trigger
    after update
    on Savout
    for each row
BEGIN
 IF ((NEW.PostedToGL = 0) and (OLD.PostedToGL <> 0)) THEN
  UPDATE `savings` SET TotDebits = TotDebits + NEW.TheAmt WHERE PlcIndex = NEW.PlcmtRef;
  UPDATE `savings` SET TotBalance = TotBalance - NEW.TheAmt WHERE PlcIndex = NEW.PlcmtRef;
  UPDATE `savings` SET UnPostedBalance = UnPostedBalance - NEW.TheAmt WHERE PlcIndex = NEW.PlcmtRef;
  UPDATE `savings` SET LastActivityDate = New.TheDate WHERE LastActivityDate < NEW.TheDate and PlcIndex = NEW.PlcmtRef;

  IF NEW.CodeSTR = 'DEBIT' THEN
   UPDATE `savings` SET TotCharges = TotCharges + NEW.TheAmt WHERE PlcIndex = NEW.PlcmtRef;
  END IF;
 END IF;
END;

