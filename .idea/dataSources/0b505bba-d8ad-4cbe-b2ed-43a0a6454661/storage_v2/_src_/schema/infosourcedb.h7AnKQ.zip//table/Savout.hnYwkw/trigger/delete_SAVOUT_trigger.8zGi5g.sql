create definer = rootinfosourcedb@`%.%.%.%` trigger delete_SAVOUT_trigger
    after delete
    on Savout
    for each row
BEGIN
 IF OLD.PostedToGL = 0 THEN
  UPDATE `savings` SET TotDebits = TotDebits - OLD.TheAmt WHERE PlcIndex = OLD.PlcmtRef;
  UPDATE `savings` SET TotBalance = TotBalance + OLD.TheAmt WHERE PlcIndex = OLD.PlcmtRef;
  UPDATE `savings` SET UnPostedBalance = UnPostedBalance + OLD.TheAmt WHERE PlcIndex = OLD.PlcmtRef;
  IF OLD.CodeSTR = 'DEBIT' THEN
   UPDATE `savings` SET TotCharges = TotCharges - OLD.TheAmt WHERE PlcIndex = OLD.PlcmtRef;
  END IF;
 END IF;

 IF OLD.PostedToGL = 1 THEN
  UPDATE `savings` SET UnPostedBalance = UnPostedBalance + OLD.TheAmt WHERE PlcIndex = OLD.PlcmtRef;
 END IF;
END;

