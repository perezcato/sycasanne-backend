create definer = rootinfosourcedb@`%.%.%.%` trigger insert_SAVIN_trigger
    after insert
    on Savin
    for each row
BEGIN 
 IF NEW.PostedToGL = 0 THEN
  UPDATE `savings` SET TotCredits = TotCredits + NEW.TheAmt WHERE PlcIndex = NEW.PlcmtRef;
  UPDATE `savings` SET TotBalance = TotBalance + NEW.TheAmt WHERE PlcIndex = NEW.PlcmtRef;
  UPDATE `savings` SET UnPostedBalance = UnPostedBalance + NEW.TheAmt WHERE PlcIndex = NEW.PlcmtRef;
  UPDATE `savings` SET LastActivityDate = New.TheDate WHERE LastActivityDate < NEW.TheDate and PlcIndex = NEW.PlcmtRef;

  IF NEW.CodeSTR = 'INTEREST' THEN
   UPDATE `savings` SET TotInterest = TotInterest + NEW.TheAmt WHERE PlcIndex = NEW.PlcmtRef;
  END IF;

  IF NEW.CodeSTR = 'DEPOSIT' THEN
   UPDATE `savings` SET LastDepositDate = New.TheDate WHERE LastDepositDate < NEW.TheDate and PlcIndex = NEW.PlcmtRef;
  END IF;
 END IF;

 IF NEW.PostedToGL = 1 THEN
  UPDATE `savings` SET UnPostedBalance = UnPostedBalance + NEW.TheAmt WHERE PlcIndex = NEW.PlcmtRef;
 END IF;
END;

