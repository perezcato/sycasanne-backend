create definer = rootinfosourcedb@`%.%.%.%` trigger delete_SAVIN_trigger
    after delete
    on Savin
    for each row
BEGIN
 IF OLD.PostedToGL = 0 THEN
  UPDATE `savings` SET TotCredits = TotCredits - OLD.TheAmt WHERE PlcIndex = OLD.PlcmtRef;
  UPDATE `savings` SET TotBalance = TotBalance - OLD.TheAmt WHERE PlcIndex = OLD.PlcmtRef;
  UPDATE `savings` SET UnPostedBalance = UnPostedBalance - OLD.TheAmt WHERE PlcIndex = OLD.PlcmtRef;

  IF OLD.CodeSTR = 'INTEREST' THEN
   UPDATE `savings` SET TotInterest = TotInterest - OLD.TheAmt WHERE PlcIndex = OLD.PlcmtRef;
  END IF;
 END IF;

 IF OLD.PostedToGL = 1 THEN
  UPDATE `savings` SET UnPostedBalance = UnPostedBalance - OLD.TheAmt WHERE PlcIndex = OLD.PlcmtRef;
 END IF;
END;

