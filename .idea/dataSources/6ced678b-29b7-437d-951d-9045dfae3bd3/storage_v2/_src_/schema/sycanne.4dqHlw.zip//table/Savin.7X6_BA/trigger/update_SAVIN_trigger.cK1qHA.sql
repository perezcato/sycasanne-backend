create definer = rootinfosourcedb@`%.%.%.%` trigger update_SAVIN_trigger
    after update
    on Savin
    for each row
BEGIN
 IF ((NEW.PostedToGL = 0) and (OLD.PostedToGL <> 0)) THEN
  UPDATE `savings` SET TotCredits = TotCredits + NEW.TheAmt WHERE PlcIndex = NEW.PlcmtRef;
  UPDATE `savings` SET TotBalance = TotBalance + NEW.TheAmt WHERE PlcIndex = NEW.PlcmtRef;
  UPDATE `savings` SET LastActivityDate = New.TheDate WHERE LastActivityDate < NEW.TheDate and PlcIndex = NEW.PlcmtRef;
  IF NEW.CodeSTR = 'INTEREST' THEN
   UPDATE `savings` SET TotInterest = TotInterest + NEW.TheAmt WHERE PlcIndex = NEW.PlcmtRef;
  END IF;
  IF NEW.CodeSTR = 'DEPOSIT' THEN
   UPDATE `savings` SET LastDepositDate = New.TheDate WHERE LastDepositDate < NEW.TheDate and PlcIndex = NEW.PlcmtRef;
  END IF;
 END IF;
END;

